
function Show1()
    {
        document.getElementById('div2').style.display ="block"; 
        document.getElementById('div1').style.display ="none";
        document.getElementById('open').style.visibility ="visible";
    }

     function Show2()
    {
        document.getElementById('div1').style.display ="grid";
        document.getElementById('div2').style.display ="none";
        document.getElementById('div3').style.display ="none";
        document.getElementById('open').style.visibility ="visible";
    }

    function Show3()
    {
        document.getElementById('div3').style.display ="block"; 
        document.getElementById('div1').style.display ="none";
        document.getElementById('open').style.display ="none";
        
        document.getElementById('div2').style.display ="none";
    }

    function show4()
    {
        document.getElementById('div4').style.display ="block"; 
         document.getElementById('checker').style.display ="none"; 
        
    }

    var video=document.querySelector("#videoElement");
    navigator.GetUserMedia=navigator.GetUserMedia||navigator.webkitGetUsermedia||navigator.mozGetUserMedia||navigator.msGetUserMedia||navigator.oGetUserMedia;

    if(navigator.getUserMedia)
    {
        navigator.getUserMedia({video:true},handleVideo,videoError)
    }

    function handleVideo(stream)
    {
        videoElement.srcObject = stream;

    }

    function videoError(e)
    {

    }


    

